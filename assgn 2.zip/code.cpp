#include <iostream>
#include <vector>
using namespace std;

class Matrix {
private:
    int rows, cols;
    vector<vector<double>> data;

public:
    // Constructor
    Matrix(int r, int c) : rows(r), cols(c), data(r, vector<double>(c, 0)) {}
    // Function to input matrix elements
    void input() 
    {
        cout << "Enter the elements of the " << rows << "x" << cols << " matrix:" << endl;
        for (int i = 0; i < rows; ++i) 
        {
            for (int j = 0; j < cols; ++j) 
                cin >> data[i][j];
            
        }
    }

    // Function to print
    void print() const 
    {
        cout << "Matrix (" << rows << "x" << cols << "):" << endl;
        for (const auto& row : data) {
            for (double val : row) 
                cout << val << " ";
            cout << endl;
        }
    }
//overloaded function
    Matrix operator*(const Matrix& other) const {
        if (cols != other.rows) {
            throw invalid_argument("Matrix dimensions do not allow multiplication.");
        }
        Matrix result(rows, other.cols);

        for (int i = 0; i < rows; ++i) {
            for (int j = 0; j < other.cols; ++j) {
                for (int k = 0; k < cols; ++k) {
                    result.data[i][j] += data[i][k] * other.data[k][j];
                }
            }
        }
        return result;
    }
};
int main() 
{
    int m, n;
    cout << "Enter the no. of rows (m) for the first matrix: ";
    cin >> m;
    cout << "Enter the no. of columns/no. of rows for second (n) for the first matrix: ";
    cin >> n;
    // Creating matrices
    Matrix matA(m, n);
    Matrix matB(n, m);
    Matrix matC(m, m);
    // Input matrix elements
    matA.input();
    matB.input();
    // Multiplying matrices
    matC = matA * matB;
    // Printing matrices
    cout << "Matrix A:" << endl;
    matA.print();
    cout << "Matrix B:" << endl;
    matB.print();
    cout << "Matrix C (A * B):" << endl;
    matC.print();
}