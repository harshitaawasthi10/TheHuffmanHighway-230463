#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

int findPlatform(vector<int>& arr, vector<int>& dep, int n) 
{
    sort(arr.begin(), arr.end());
    sort(dep.begin(), dep.end());
    int platform_needed = 1, result = 1;
    int i = 1, j = 0;

    while (i < n && j < n) {
       
        if (arr[i] <= dep[j]) {
            platform_needed++;
            i++;
        }
       
        else {
            platform_needed--;
            j++;
        }

        if (platform_needed > result)
            result = platform_needed;
    }

    return result;
}

int main() 
{
    int n;
    cout << "Enter the number of trains: ";
    cin >> n;

    vector<int> arrival(n), departure(n);
    cout << "Enter the arrival times: ";
    for (int i = 0; i < n; i++) 
    {
        cin >> arrival[i];
    }

    cout << "Enter the departure times: ";
    for (int i = 0; i < n; i++) 
    {
        cin >> departure[i];
    }
    cout << "Minimum Platforms = " << findPlatform(arrival, departure, n) << endl;
}
