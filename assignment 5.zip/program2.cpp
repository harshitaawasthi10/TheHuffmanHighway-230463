#include <iostream>
#include <vector>
#include <queue>
using namespace std;

int minCostToMergeFiles(vector<int>& file_sizes) {
   
    priority_queue<int, vector<int>, greater<int>> minHeap(file_sizes.begin(), file_sizes.end());

    int minCost = 0;
    while (minHeap.size() > 1) 
    {
        int first = minHeap.top();
        minHeap.pop();
        int second = minHeap.top();
        minHeap.pop();
        int cost = first + second;
        minCost += cost;
        minHeap.push(cost);
    }
    return minCost;
}

int main() {
    int n;
    cout << "Enter the number of files: ";
    cin >> n;
    vector<int> file_sizes(n);
    cout << "Enter the sizes of the files: ";
    for (int i = 0; i < n; i++) {
        cin >> file_sizes[i];
    }
    cout << "Minimum Cost = " << minCostToMergeFiles(file_sizes) << endl;
}