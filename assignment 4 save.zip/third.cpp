#include <iostream>
#include <string>
#include <vector>
using namespace std;

string lsr(const std::string &s) {
    int n = s.size();
    string doubled = s + s; // Concatenate the string with itself
    vector<int> f(2 * n, -1);
    int k = 0; // Least rotation of string
    for (int j = 1; j < 2 * n; ++j) {
        char sj = doubled[j];
        int i = f[j - k - 1];
        while (i != -1 && sj != doubled[k + i + 1]) {
            if (sj < doubled[k + i + 1]) {
                k = j - i - 1;
            }
            i = f[i];
        }
        if (sj != doubled[k + i + 1]) {
            if (sj < doubled[k]) {
                k = j;
            }
            f[j - k] = -1;
        } else {
            f[j - k] = i + 1;
        }
    }

    return doubled.substr(k, n);
}

int main() {
    string s;
    cout<<"enter a string";
    cin>>s;
    string smallestRotation = lsr(s);
    cout << "Lexicographically smallest rotation: " << smallestRotation << endl;
    return 0;
}