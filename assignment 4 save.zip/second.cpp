# include <iostream>
using namespace std;
struct ListNode{
    int val;
    listnode* next;
    ListNode(int x) : val(x), next(nullptr) {}
};

class Solution {
public:
    ListNode* rotateRight(ListNode* head, int k) {
        if (!head || k == 0) return head;

        ListNode* temp = head;
        int length = 1;  
        while (temp->next) {
            temp = temp->next;
            length++;       //length is the length of the linked list
        }
        temp->next = head;  //making the linked list circular
        k = k % length;
        int stepsToNewHead = length - k;
        ListNode* newTail = head;
        for (int i = 1; i < stepsToNewHead; i++) 
            newTail = newTail->next;
        
        ListNode* newHead = newTail->next;
        newTail->next = nullptr;
        return newHead;
    }
};

// function to print the linked list
void printList(ListNode* head) 
{
    while (head) 
    {
        std::cout << head->val << " -> ";
        head = head->next;
    }
    std::cout << "NULL" << std::endl;
}