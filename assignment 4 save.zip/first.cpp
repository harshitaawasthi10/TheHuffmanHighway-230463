#include <iostream>
using namespace std;

bool isPalindrome(Node* head) 
{
    if (!head || !head->next) 
    {
        return true; // Empty list or single element list is a palindrome
    }

    Node* slow = head;
    Node* fast = head;
    stack<int> s;
    while (fast && fast->next) {
        s.push(slow->value);
        slow = slow->next;
        fast = fast->next->next;
    }
    if (fast) {
        slow = slow->next;
    }
    while (slow) {
        int top = s.top();
        s.pop();
        if (top != slow->value) {
            return false;
        }
        slow = slow->next;
    }

    return true;
}